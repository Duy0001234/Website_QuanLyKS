app = angular.module("admin-app", ["ngRoute"]);

app.config(function($routeProvider) {
    $routeProvider
        .when("/phong", {
           templateUrl:"/admin/phong/index.html",
            controller: "phong-ctrl"
        })
         .when("/khachhang", {
           templateUrl:"/admin/khachhang/index.html",
            controller: "khachhang-ctrl"
        })
        .when("/home", {
            templateUrl:"/admin/home/index.html",
           controller: "home-ctrl"
        })
         .when("/datphong", {
            templateUrl:"/admin/datPhong/index.html",
           controller: "datphong-ctrl"
        })
         .when("/listDaPhong", {
            templateUrl:"/admin/danhsachDatPhong/index.html",
//           controller: "home"
        })
         .when("/dichvu", {
            templateUrl:"/admin/dichVu/index.html",
           controller: "dichvu-ctrl"
        })
         .when("/khuyenmai", {
            templateUrl:"/admin/khuyenMai/index.html",
//           controller: "home"
        })
         .when("/loaiphong", {
            templateUrl:"/admin/loaiPhong/index.html",
           controller: "loaiphong-ctrl"
        })
         .when("/danhsachdatphong", {
            templateUrl:"/admin/danhSachDatPhong/formDanhSachDatPhong.html",
//           controller: "home"
        })
         .when("/detailHoaDon", {
            templateUrl:"/admin/hoaDon/detail.html",
           controller: "hoaDonDetail-ctrl"
        })
         .when("/orderDV", {
            templateUrl:"/admin/orderDichVu/index.html",
           controller: "orderDV-ctrl"
        })
         .when("/traphong", {
            templateUrl:"/admin/traPhong/index.html",
           controller: "traphong-ctrl"
        })
        
       .otherwise({
            templateUrl:"/admin/home/index.html",
            controller: "home-ctrl"
        }); 
});
