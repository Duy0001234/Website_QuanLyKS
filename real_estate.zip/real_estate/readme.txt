Các bước chạy project vs docker:
1. Mở terminal project
2. docker build -t jwt-app
3. docker-compose up -> khởi tạo image thành container
4. mở postman test
5. trỏ vào terminal -> ctrl + c để stop docker compose
6. docker-compose down -> xoá toàn bộ container lưu trữ